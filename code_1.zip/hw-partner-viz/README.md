### Setup

1. Start local server in the same folder as index.html file:

For python 2:
```
python -m SimpleHTTPServer
```

For python 3:
```
python -m http.server
```

2. Load file into browser:

```
http://0.0.0.0:8000/index.html
```
or
```
 http://localhost:8000/index.html
```
